#coding:utf8
from setuptools import setup, find_packages

setup(
    name='utrac_label',         # 应用名
    version='1.0',        # 版本号
    packages=['utrac_label'],
    include_package_data=True,
)