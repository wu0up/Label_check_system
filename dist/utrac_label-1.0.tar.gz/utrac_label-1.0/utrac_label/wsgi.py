import sys
sys.path.insert(0, '/utrac_lable/')
 
from utrac_label import app as application

if __name__=='__main__':
    application.run()